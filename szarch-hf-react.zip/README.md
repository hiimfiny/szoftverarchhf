Első futtatás előtt 
>npm install

Aztán
>npm start
használatával elindul az alkalmazás

Egyelőre a frontend bizonyos részei működnek csak.
Az összerakás során előfordultak random új hibák, és nem volt idő rendesen debugolni őket.