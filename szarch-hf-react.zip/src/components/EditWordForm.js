import React from 'react'
import { useState } from 'react'
import Wordpairs from './Wordpairs'

const EditWordForm = ({onEdit, showEdit, wordpairs, id}) => {
    const [word,setWord] = useState('')
    const [meaning,setMeaning] = useState('')
    const [diff,setDiff]= useState('')
    
    const tempArray = wordpairs.pairs
    var temppair=null;
    const findPair = ()=>{
        for(let i=0; i<tempArray.length; i++){
            if(tempArray[i].id === id)
                temppair=tempArray[i]
        }
         


    }
    findPair()
    console.log('a')
    const onSubmit = (e) => {
        e.preventDefault()
        
        const ret = {'word': word ==='' ? temppair.word : word, 
                    'meaning': meaning ==='' ? temppair.meaning : meaning, 
                    'diff':diff === '' ? temppair.diff : diff}
        console.log(ret)
        onEdit(id, ret)
        showEdit()
    }   
    
    return (
        
        <form className='editWord' onSubmit={onSubmit}>
            <div className='form-control'>
                <label>Word</label>
                <input type='text' placeholder={temppair.word} 
                value={word === '' ? temppair.word : word} 
                onChange={(e) => setWord(e.target.value)}/>
            </div>

            <div className='form-control'>
                <label>Meaning</label>
                <input type='text' placeholder='' 
                value={meaning === '' ? temppair.meaning : meaning} 
                onChange={(e) => setMeaning(e.target.value)}/>
            </div>

            <div className='form-control'>
                <label>Difficulty</label>
                <input type='text' placeholder='' 
                value={diff === '' ? temppair.diff : diff} 
                onChange={(e) => setDiff(e.target.value)}/>
            </div>

            <input className='btn' type='submit' value='Save word' />
        </form>
    )
}

export default EditWordForm
