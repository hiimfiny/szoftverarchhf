import './App.css';
import Button from './components/Button';
import Register from './components/Register';
import Login from './components/Login';
import { useState } from "react"
import Header from './components/Header';
import Wordpairs from './components/Wordpairs';
import Sentences from './components/sentence/Sentences';


function App() {
  const [wordpairs, setPairs] = useState(
    {
        lang1: 'eng',
        lang2: 'hun',
        pairs: [
            {
                id: 1,
                diff: 1,
                word: 'cat',
                meaning: 'macska',
            },
            {
                id: 2,
                diff: 3,
                word: 'hammer',
                meaning: 'kalapács',
            },
            {
                id: 3,
                diff: 6,
                word: 'apathy',
                meaning: 'fásultság',
            },
            
        ],
        sentences: [
          {
            id: 1,
            sentence: 'The cat climbed ___ the tree',
            a: 'on',
            b: 'to',
            c: 'in',
            d: 'from',
            diff: 1,
          },
          {
            id: 2,
            sentence: 'He ___ that she would pass',
            a: 'insured',
            b: 'ensured',
            c: ' assumed',
            d: 'assured',
            diff: 6,
          },
        ]
    })
    

  const[showRegister, setShowRegister] = useState(false)
  const[showLogin, setShowLogin] = useState(false)
  

  const setRegFunc = () => {setShowRegister(!showRegister)}
  const setLogFunc = () => {setShowLogin(!showLogin)}

  const addUser = (user) => {
    console.log(user)
}

  const login = (user) => {
    console.log(`Welcome ${user.usr}`)
  }

  const addWord = (wordpair) => {
    console.log(wordpair)
    const id=wordpairs.pairs.length+1
    const newWord = {id, ...wordpair}
    setPairs({pairs: [...wordpairs.pairs, newWord]})
    console.log(wordpairs.pairs.length)
  }

  const editWord = (id, wordpair) => {
    console.log(id, "edited")
    const tempArray = wordpairs.pairs
      
    for(let i=0; i<tempArray.length; i++){
        if(tempArray[i].id === id){
          tempArray[i].word=wordpair.word
          tempArray[i].meaning=wordpair.meaning
          tempArray[i].diff=wordpair.diff
        }
      }
      setPairs({pairs: tempArray})
  }

  const onDelete = id =>{
    console.log('delete', id)
    setPairs({pairs: wordpairs.pairs.filter(pair=> pair.id !== id)})
    
  }

  const addSentence = (sentence) => {
    console.log(sentence)
    const id=wordpairs.sentences.length+1
    const newSent = {id, ...sentence}
    console.log(newSent)
    setPairs({sentences: [...wordpairs.sentences, newSent]})
  }
  const deleteSent = id =>{
    console.log('delete', id)
    setPairs({sentences: wordpairs.sentences.filter(sent=> sent.id !== id)})
  }
  const editSentence = (id, sentence) => {
    console.log(id, 'edited')
    const  tempArray = wordpairs.sentences
    for(let i=0; i<tempArray.length; i++){
      if(tempArray[i].id === id){
        tempArray[i].sentence=sentence.sentence
        tempArray[i].a=sentence.a
        tempArray[i].b=sentence.b
        tempArray[i].c=sentence.c
        tempArray[i].d=sentence.d
        tempArray[i].diff=sentence.diff
      }
    }
    setPairs({sentences: tempArray})


  }
  return (
    <div className="App">
      <Header regfunc = {setRegFunc} logfunc = {setLogFunc} />
    
      <div>
      {showRegister && <Register onRegister={addUser}
      onClick={()=>setShowRegister(!showRegister)}/>}

      {showLogin && <Login onLogin={login} 
      onClick={()=> setShowLogin(!showLogin)}/>}
      </div>
      <div>
      <Wordpairs wordpairs={wordpairs} onAdd={addWord}
                  onEdit ={editWord} onDelete={onDelete}/>
      </div>
      {/*
      <div>
        <Sentences sentences={wordpairs.sentences} 
        onAddSentence={addSentence}
        onEdit={editSentence}
        onDelete={deleteSent}/>
      </div>
      */}


    </div>
    
  );
}

export default App;
